package animals;

public interface SoundProducible {
    void produceSound();
}
