package telefony;

public interface Callable {
    void call(String s);
}
