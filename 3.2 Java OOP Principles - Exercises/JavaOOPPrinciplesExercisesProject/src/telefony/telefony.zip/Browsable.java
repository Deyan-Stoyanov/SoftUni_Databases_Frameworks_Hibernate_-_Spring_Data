package telefony;

public interface Browsable {
    void browse(String s);
}
