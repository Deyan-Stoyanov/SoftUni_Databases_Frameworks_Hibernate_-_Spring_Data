package radio.database;

public class InvalidSongLengthException extends InvalidSongExeption {
    public InvalidSongLengthException(String message) {
        super(message);
    }
}
