package radio.database;

public class InvalidSongNameException extends InvalidSongExeption {
    public InvalidSongNameException(String message) {
        super(message);
    }
}
